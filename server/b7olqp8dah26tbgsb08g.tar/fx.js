module.exports = (input) => {
    return parseInt(input.a, 10) + parseInt(input.b, 10)
}
