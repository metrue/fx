def fx(input):
    return input['a'] + input['b']
