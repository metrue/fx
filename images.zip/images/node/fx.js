module.exports = (input) => {
    return input.a + input.b
}
