def fx(j):
    return j.a + j.b
