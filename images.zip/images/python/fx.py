def fx(j):
    return j
