FROM sgerrand/alpine-r

COPY . /usr/local/src/fx
WORKDIR /usr/local/src/fx
RUN mkdir ~/R

RUN R -f packages.R
