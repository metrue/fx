<?php
    function Fx($a,$b) {
        return $a+$b;
    }
