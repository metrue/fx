<?php
    function Fx($input) {
        return $input["a"]+$input["b"];
    }
