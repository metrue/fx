def fx(input)
    input["a"] + input["b"]
end
